format long g
x=1; omegav=x/(x*182.5);
eps1=0.8; eps2=0.8;eps3=0.8;
n=4;m=4;
Ac=load('new_nb_Data/Ac.csv');
DYZ=load('new_nb_Data/DYZ.csv'); 
NGM_orig=load('nb_Data/NGM.csv'); 
NGM=load('new_nb_Data/NGM.csv');
Y1=load('new_nb_Data/Y1.csv');Y1=Y1'; %'
Z1=load('new_nb_Data/Z1.csv');Z1=Z1'; %'
%% action
n2=size(Ac,1);m2=size(Ac,2);
chk1=norm(DYZ*Ac-NGM_orig,1)
chk2=norm(DYZ*Ac-NGM,1)
[vv,ee]=eig(Ac);ee=diag(ee);
[~,p]=sort(-abs(ee)); vv=vv(:,p);ee=ee(p);
mp=fix(n2/2);
I=speye(mp);np=mp;
P0=sparse(n2,mp);
P0(1:2:end,:)=I; P0(2:2:end,:)=-I;
P0=(sqrt(2)/2)*P0;
P=abs(P0);
chk_ker=norm(Ac*P0,1)
DYZ1=spdiags(1./diag(DYZ),[0],n2,m2);
%% ee1 are eig(NGM) as well
[vv1,ee1]=eig(Ac,DYZ1);ee1=diag(ee1);
[~,p1]=sort(-abs(ee1)); vv1=vv1(:,p1);ee1=ee1(p1);
% ee2=eig(NGM)
[vv2,ee2]=eig(NGM);ee2=diag(ee2);
[~,p2]=sort(-abs(ee2)); vv2=vv2(:,p2);ee2=ee2(p2);
chk_eig=norm(ee2-ee1,1)
%%
Acp=P'*Ac*P;%'
dyz=diag(DYZ);
DYZp=P'*DYZ*P;%'
dyzp=diag(DYZp);
%%for k=1:np
%%    k2=2*k;
%%    vz(k,1)=0.5*(dyz(k2-1)+dyz(k2))-dyzp(k);
%%end
vz=0.5*(dyz(1:2:n2)+dyz(2:2:n2))-dyzp;
chk_diags=norm(vz,1)
%%
y1=reshape(Y1,n*m,1);
z1=reshape(Z1,n*m,1);
dyza(2:2:n2,1)=z1;
dyza(1:2:n2,1)=y1;
chck_dyz=norm(dyz-dyza,1)
dyzp1=1./dyzp;
DYZp1=spdiags(dyzp1,[0],np,mp);
[vvp,eep]=eig(Acp,DYZp1);eep=diag(eep);
[~,pp]=sort(-abs(eep)); vvp=vvp(:,pp);eep=eep(pp);
chk_eig_nnz=norm(ee1(1:16)-eep,1)
%%%%%%%%%%%%%%%%%%%%% up to here is general enough; now looking at a special case of chi1.
chi1_0=load('new_nb_Data/chi1Matrix_0.csv');
chi1=reshape(chi1_0',n*m,1); %' this is chi1 by rows stored as a column vector. 
t=chi1/omegav;td=1./(1+t);
y1_a=td;c2=1-eps2;
z1_a=c2*(1-td);
chky=norm(y1_a-y1,1) %% watch for y1 and transpose(y1); 
chkz=norm(z1_a-z1,1) %%  watch for z1 and transpose(z1); 

%xdyza(2:2:n2,1)=c2*(1-td);
%xdyza(1:2:n2,1)=td;
%xvz=0.5*(td+c2*(1-td))-dyzp;
%xvz=0.5*((1-c2)*td+c2)-dyzp;
%xvz=0.5*((1-c2)*(1./(1+t))+c2)-dyzp;
%xvz=0.5*(  c2*(t./(1+t))+1./(1+t))-dyzp;
%xvz=0.5*(1./(1+t)).*( c2*t+1)-dyzp;
%% inverse is:
xdyzp1=(1+t)./(c2*t+1);
chk_var=norm(xdyzp1-0.5*dyzp1,1)
xDYZp1=spdiags(xdyzp1,[0],np,mp);
[xvvp,xeep]=eig(Acp,xDYZp1);xeep=diag(0.5*xeep);
[~,xpp]=sort(-abs(xeep)); xvvp=xvvp(:,xpp);xeep=xeep(xpp);
chk_eig_nnz1=norm(ee1(1:16)-xeep,1)

%%zdyzp= (1-c2+c2+c2*t)./(1+t); %%%(1+c2*t)./(t+1);
%zdyzp= 1-eps2+eps2./(1+t);
zdyzp= 1-eps2+eps2*(omegav./(omegav+chi1));
zDYZp=spdiags(zdyzp,[0],np,mp);
[zvvp,zeep]=eig(zDYZp*Acp);zeep=diag(0.5*zeep);
[~,zpp]=sort(-abs(zeep)); zvvp=zvvp(:,zpp);zeep=zeep(zpp);
chk_eig_nnz2=norm(ee1(1:16)-zeep,1)

%% swap D and A:
yDYZp=spdiags(zdyzp,[0],np,mp);
[yvvp,yeep]=eig(Acp*yDYZp);yeep=diag(0.5*yeep);
[~,ypp]=sort(-abs(yeep)); yvvp=yvvp(:,ypp);yeep=yeep(ypp);
chk_eig_nnz3=norm(ee1(1:16)-yeep,1)

[vvap,eeap]=eig(Acp);eeap=diag(eeap);
[~,pap]=sort(-abs(eeap)); vvap=vvap(:,pap);eeap=eeap(pap);

