# Mathematica notebooks in `MathBio` — what each one contains

Survey of the twelve `.nb` files in this directory (all from Jan–May 2025).
Extracted with a kernel script that pulls the `Input`, section and `Output`
cells out of each notebook; no notebook was re-evaluated.

---

## 1. The common model

Eleven of the twelve notebooks are variants of one computation: the
next-generation matrix and basic reproduction number of a meta-population
COVID model with vaccination.

**Index structure.** `m = 4` regions `{Northeast, Midwest, South, West}`
by `n = 4` age groups `{0–19, 20–39, 40–59, 60+}`; sixteen groups in all.

**Epidemiological compartments.** Eight infected states per group, visible in
the `mV` block:

| state | flow |
| --- | --- |
| E (unvaccinated exposed) | rate `k` out |
| Ev (vaccinated exposed) | rate `k` out |
| A (asymptomatic) | `vp[j]`, `vq[j]` in, `vγa[j]` out |
| Ps (pre-symptomatic → severe) | `k(1-vp[j])` in, `ξ` out |
| Is (severe) | `ξ` in, `vγs[j] + vδs[j]` out |
| H (hospitalized) | `vδs[j]`, `vδm[j]` in, `vγh[j]` out |
| Pm (pre-symptomatic → mild) | `k(1-vq[j])` in, `ξ` out |
| Im (mild) | `ξ` in, `vγm[j] + vδm[j]` out |

**Rate parameters** (set in the first input cell of every notebook):
`γa = 1/7`, `γs = γm = 1/5`, `γh = 1/10`, `k = x/5`, `ξ = x/2`,
waning `ω = ωv = x/182.5`, vaccine efficacies `ϵ1 = ϵ2 = ϵ3 = 0.8`,
`bS = bI = 0.31`. The factor `x` is the time unit: `x = 1` for days,
`x = 7` for weeks. Which value is used is the main split between the two
`F_ZF*` notebooks (`x = 7`) and most `eigenvalues_H*` notebooks (`x = 1`);
`eigenvalues_H.nb` and `eigenvalues_H_ZF5.nb` also use `x = 7`.

**Data arrays**, hard-coded as literals in every notebook:

- `mN` — 4×4 population counts by region × age (1.29e7 … 3.41e7).
- `ma` — 4×4 activity/mixing amplitudes.
- `vβ` — per-age transmission rates `{0.0794, 0.0738, 0.0809, 0.2147}`
  (scaled by 25 in `eigenvalues_H.nb`).
- `mc` — 4×4×4×4 contact tensor (region × age × region × age).
- `vp`, `vq` — age-dependent asymptomatic fractions for the severe and
  mild routes.
- `vδs`, `vδm` — age-dependent hospitalization rates.
- `vη = {ηa, ηps, ηpm, ηs, ηm, ηh} = {0.5, 1.25, 1, 1, 0.75, 0.1}` —
  relative infectiousness by state (the cells carry a comment noting that
  the order of `vη` is not the natural one).

**Vaccination.** `mχ1`, `mχ2`, `mχ3` are the 4×4 per-group rates for doses
1, 2 and 3. The disease-free equilibrium splits each group's susceptibles
into unvaccinated `sdfe`, once-vaccinated `vdfe` and further-vaccinated
`pdfe`, all as rational functions of the `mχ` and `ω`. The two transmission
coefficients follow:

```
Y[i,j] = vψS[j] vS[i] ma[i,j] vβ[j] sdfe[i,j] / mN[i,j]
Z[i,j] = vψS[j] vS[i] ma[i,j] vβ[j] ((1-ϵ1) vdfe[i,j] + pdfe[i,j]) / mN[i,j]
```

**Assembly of the next-generation matrix.** `Q` is the diagonal matrix of
`η`-weighted mean infectious durations,
`Q0[j] = ηa Pas[j] Ta[j] + ηps Pps[j] Tp + ηs Ps[j] Ts[j]`, repeated per
group. `Ωmat[i] = diag(Y[i,1], Z[i,1], …, Y[i,n], Z[i,n])`, `ccMat[i,p]` is
the contact tensor re-laid-out as 2n×2n blocks, `ψImat[p]` is the
infectiousness-reduction diagonal. Then

```
mH[i,p] = Ωmat[i] . ccMat[i,p] . ψImat[p] . Q
```

and the sixteen blocks are joined into a 32×32 matrix `NGM`
(`m × 2n = 32`). `R0` is `Eigenvalues[NGM, 1]`; the left eigenvector
`Eigenvectors[Transpose[NGM], 1]` is reshaped into region × age and plotted
as the per-group reproduction numbers.

**Exports.** All notebooks `SetDirectory` to a data folder and export the
pieces as CSV — `nMatrix.csv`, `aMatrix.csv`, `cMatrix.csv`,
`betaVector.csv`, `chi1Matrix.csv`, `snMatrix.csv`, `vnMatrix.csv`,
`pnMatrix.csv`, `yMatrix.csv`, `zMatrix.csv`, `qMatrix.csv`, `hMatrix.csv`,
`NGM.csv`. Most point at
`~/github/ludmil02/Working_dirs/MathBio/nb_Data`; that directory
exists here as `./nb_Data` with 17 CSVs. `eigenvalues_H_ZF4.nb` points at a
co-author's Windows path
(`C:\Users\zfeng\OneDrive - National Science Foundation\ZF\1IRD\Glasser\MS24\Ludmil\H_matrix\`),
and `new_eigenvalues_H_ZF_JG.nb` at `.../MathBio/new_nb_Data`.

**Two named methods.** Most notebooks end with two sections:

- *John's method* — the per-group reproduction numbers read off the left
  Perron eigenvector of `NGM`, plotted against age with one curve per
  region (`f11`).
- *Method by Ludmil and Yuliya* — a stored `OptimalChi1`, a 4×4 matrix of
  optimal dose-1 allocation rates computed elsewhere (carried at 18-digit
  precision), substituted back into `mχ1` to recompute `R0`, plus a
  dose-budget constraint check.

---

## 2. The `F_ZF*` family — explicit F and V

These two build the full van den Driessche–Watmough pair before reducing.

### `F_ZF_30Dec.nb` (989 KB, 16 Jan 2025, 175 cells)

The most detailed construction. `x = 7` (weekly rates).

- Builds `mF` as a 4×4×4×4 array of 8×8 blocks: rows 1–2 (E and Ev) receive
  `Y[i,j] ψI[q] η• c[i,p,j,q]` and `Z[i,j] ψI[q] η• c[i,p,j,q]` from each of
  the six infectious states; all other rows zero.
- Builds `mV` as the transition matrix given in the table above, nonzero
  only for `p = i` (transitions stay within a region).
- Forms `FminusV`, and reshapes `mF` into a flat 128×128 matrix
  (`ArrayReshape[mF, {128,128}]`) whose leading eigenvalues are computed.
- `test1`, `test2` are partial block-joins of `F - V` over the first three
  age groups and first two regions — assembly experiments, not a finished
  128×128 join.
- Exports `Fmatrix.csv`, `mF1222.csv`, `cMatrix.csv`, `NMatrix.csv`,
  `chi1Matrix.csv`–`chi3Matrix.csv`.
- Susceptible fractions are the time-347 values
  `vψS = {0.8226, 0.8239, 0.8292, 0.8242}`,
  `vS = {0.7024, 0.7350, 0.7178, 0.6536}`; `mχ1`–`mχ3` are left symbolic at
  first, then set to the literal coverage matrix
  `{{0.25, 0.50, 0.16, 0.12}, …}`.

### `F_ZF+eig.nb` (370 KB, 18 Jan 2025, 246 cells)

`F_ZF_30Dec` with the noisy cells wrapped in `Quiet`, plus the eigenvalue
work appended.

- Same `mF`/`mV`/`FminusV` construction; the 128×128 reshape is renamed
  `Z123` (in `F_ZF_30Dec` the name `Z` collided with the transmission
  coefficient `Z`). Its three largest eigenvalues:
  `{0.1044, -0.00248, 0.000483}`.
- Then a second half that rebuilds the reduced `H` matrix from `Ωmat`,
  `ccMat`, `ψImat` — here without the `Q` factor,
  `mH[i,p] = Ωmat[i] . ccMat[i,p] . ψImat[p]` — and joins **nine** blocks
  `L1…L9` rather than four.
- This is the one notebook where `ϵ1`, `ϵ2`, `ϵ3`, `vψS`, `vS` and `vβ` are
  given as functions of `t` (`ϵ2[t]`, `vψS[t][[j]]`, `vβ[t][[j]]`), i.e.
  the time-dependent version of the coefficients.

---

## 3. The `eigenvalues_H*` family — the reduced 32×32 NGM

Seven notebooks, an evolving sequence rather than seven separate
calculations.

### `eigenvalues_H.nb` (139 KB, 26 Jan 2025, 104 cells)

Earliest of the series. `x = 7`, `vβ` scaled by 25. Susceptible fractions
are the time-347 values
`vψS = {0.7782, 0.7799, 0.7866, 0.7802}`,
`vS = {0.3586, 0.4312, 0.4612, 0.3916}`.
Two `mχ1` settings appear: the literal coverage matrix and a later uniform
per-region one (`0.00312…`, `0.00370…`, `0.00276…`, `0.00373…`) with
`mχ2 = mχ3 = 1`. Contains a regression check `YY - Y`, `ZZ - Z` against
stored values. No John/Ludmil–Yuliya sections yet. Result:
`Re[Eigenvalues[NGM, 17]]` → `44.72`.

### `eigenvalues_H_ZF2.nb` and `eigenvalues_H_ZF3.nb` (175 KB each, 26 Jan 2025, 114 cells)

**The same computation** — the extracted cell content of the two is
identical; only notebook metadata differs. `x = 1`, `vψS = vS = 1`,
`mχ1` the literal coverage matrix. Both add the *John's method* and
*Method by Ludmil and Yuliya* sections. Two candidate `OptimalChi1` matrices
are recorded, entered once as `2.643…*Exp[-3]` and once as
`2.029…/10^3`. Result: `R0 = 1.98388`.

### `eigenvalues_H_ZF4.nb` (241 KB, 30 Jan 2025, 155 cells)

`ZF3` plus four new subsections, and the co-author's Windows output path.

- `OptimalChi1` is re-entered in plain decimal form (`0.002643…`).
- *RN with the optimal Chi1* — substitutes `OptimalChi1` into `mχ1`, zeroes
  `mχ2`/`mχ3`, recomputes: `R0 = 4.8487`.
- *RN with the Chi1 values following the pattern shown in Figure f11* —
  scales the per-group eigenvector profile `l0` into a `newChi1` and
  recomputes: `R0 = 4.7257`.
- *Checking constraint for Chi1* — the dose budget. `Sstar` is the
  time-347 susceptible matrix, `TotalDoses = {146870, 227440, 306438, 267291}`
  per age group, and `Total[Transpose[newChi1 * Sstar]]` is compared
  against it.
- *So, the constraint is satisfied* — followed by the `f11C` plot of
  `newChi1`.

Baseline result unchanged at `1.98388`.

### `eigenvalues_H_ZF5.nb` (300 KB, 30 Jan 2025, 176 cells)

`ZF4` back on the Linux path, with `x = 7` and a third `OptimalChi1`
(first entry `0.003005…`, fourth entry `2.24e-14` — the optimizer drives the
60+ allocation to zero in three of four regions). Adds `NGMx`, the NGM under
the optimal allocation, exported as `NGMx.csv`. Results: baseline
`R0 = 1.98388`; optimal-`χ1` `R0 = 4.7128`; pattern-`χ1` `R0 = 4.7257`;
`newChi1` doses `{146870.007, 227440.006, 306438.015, 267291.002}`, matching
the budget.

### `eigenvalues_H_ZF5_v2.nb` (402 KB, 11 Feb 2025, 214 cells)

The most developed of the family, and the one where the factorization of `H`
is examined. `x = 1`, `vψS = vS = 1`.

- Introduces `Y1`, `Z1`, `sdfe1` (the `mN`-free versions of `sdfe`, `Y`,
  `Z`) and the diagonal `DYZ1`, then verifies the factorization
  `mHz[i,p] = DYZ1[i] . Ωmat1[i] . ccMat[i,p] . ψImat[p] . Q` against
  `mH` via `Norm[Flatten[mHz - mH]]`.
- `noChi` and `noChi1` strip the `χ`-dependence (and, for `noChi1`, the
  diagonal in `ma`, `ψS`) out of `H`, so the `χ`-dependent part can be
  isolated for the optimization.
- Adds a section *Matrices involved in H (not including Ωmat): ccMat,
  ψImat, and Q* displaying those three factors.
- Exports a whole `z*`-prefixed set: `zY.csv`, `zZ.csv`, `zY1.csv`,
  `zZ1.csv`, `zoMatrix.csv`, `zo1Matrix.csv`, `zdyzMatrix.csv`,
  `zNGM.csv`, `Aconst.csv`, `zchi1Matrix.csv`–`zchi3Matrix.csv`.
- Results at `x = 1`: baseline `R0 = 4.4231`; optimal-`χ1` `R0 = 2.9248`;
  pattern-`χ1` `R0 = 2.9359`. `newChi1` is listed explicitly
  (`{{0.003842, 0.004261, 0.003983, 0.000593}, …}`) and satisfies the dose
  constraint.

### `orig_eigenvalues_H_ZF_JG.nb` (164 KB, 15 May 2025, 96 cells)

The zero-vaccination reference case: `mχ1 = mχ2 = mχ3 = 0`,
`vψS = vS = vψI = 1`, `x = 1`. This is the unvaccinated `R0 = 4.42307`,
the same number `ZF5_v2` gets at `x = 1` with the literal coverage matrix —
so in that configuration the `χ` values move `R0` very little.
`Re[Eigenvalues[NGM, 17]]` returns sixteen `ComplexInfinity` entries (the
`Eigenvalues[m, 17]` call on a rank-deficient 32×32 matrix). Ends with the
`Flatten[Y]/Flatten[Z]` ratio and a regression check `Norm[… - before]`
against a stored sixteen-vector.

### `eigenvalues_H_ZF_JG.nb` (168 KB, 30 May 2025, 99 cells)

Same structure, but with a **random-looking `mχ1`** — entries spread over
`0.168 … 0.908` rather than the small realistic rates. Several parameter
assignments in the first cell lost their semicolons (`ωv = …` and
`ϵ1 = 0.8` print their values). At that coverage `R0 = 0.9335`, i.e. below
one. The `Y/Z` regression check gives `Norm = 5.09`, so the `Y/Z` ratios
have moved from the stored `before` vector.

### `new_eigenvalues_H_ZF_JG.nb` (212 KB, 30 May 2025, 130 cells)

The `ZF_JG` case reworked in the `ZF5_v2` factorized form, exporting to
`new_nb_Data`.

- Same high `mχ1` and `R0 = 0.9335`.
- Carries `Ωmat1`, `Dconst1` and the check
  `mHz[i,p] = Ωmat1[i] . Dconst1[i] . ccMat[i,p] . ψImat[p] . Q`
  against `mH` (norm `2.48e-16`).
- `noChi1[i,p] = Dconst1[i] . ccMat[i,p] . ψImat[p] . Q` — the comment
  says *"This is exported has no chi and no diagonal matrix depending on
  ma, psiS, etc"*. Exported as `Ac_1.csv`, with `DYZ_1.csv`, `Y1_1.csv`,
  `Z1_1.csv` and the `_0`-suffixed `chi*Matrix_0.csv`,
  `p1Matrix_0.csv`, `s1Matrix_0.csv`.

---

## 4. `16_Group_Model_Results_t=347_ZF.nb` (137 KB, 24 Jan 2025, 74 cells)

Not a reproduction-number notebook — it is the post-processing of a
simulation. The ODE system itself is not in any of the twelve files (no
`NDSolve` appears anywhere); this notebook evaluates a stored solution
`soln1` at `t = 347` and records the numbers the other notebooks then use as
literals:

- `mV[[i,j]][347]` — all zero.
- `mP[[i,j]][347]` — the further-vaccinated compartment,
  `{{617719, 822041, 619036, 356299}, …}`.
- `mS[[i,j]][347]` — the susceptible matrix, the `Sstar` that reappears in
  `ZF4`/`ZF5`/`ZF5_v2`.
- `vψS[347]`, `vψI[347]` = `{0.7782, 0.7799, 0.7866, 0.7802}` and
  `vS[347]` = `{0.3584, 0.4312, 0.4619, 0.3917}` — the susceptible fractions
  that `eigenvalues_H.nb` and `eigenvalues_H_ZF5.nb` use.
- `C1` — dose-1 availability `b_{1i}` aggregated from a 50-state weekly
  table `Wk1` into the four regions (the state index sets per region are
  spelled out in the `Sum` calls) and four age bands.
- `C2` — the resulting `{{279, 62294, 60028, 24269}, …}`, whose column
  totals `{146870, 227440, 306438, 267291}` are the `TotalDoses` budget used
  in the constraint checks above.
- Exports `b1Vector.csv`, `s1Matrix.csv`, `v1Matrix.csv`, `p1Matrix.csv`.

The section headings name the intent: *"values for P(T-1) (at T-1 = 347, to
be used in the constraint equation) for the 4 age groups at locations 1–4"*.

---

## 5. Summary of the reproduction numbers

| notebook | `x` | `ψS`, `S` | `mχ1` | `R0` |
| --- | --- | --- | --- | --- |
| `eigenvalues_H` | 7 | t=347 values | uniform per region | 44.72 (`β` ×25) |
| `eigenvalues_H_ZF2` / `ZF3` | 1 | 1 | literal coverage | 1.98388 |
| `eigenvalues_H_ZF4` | 1 | 1 | literal coverage | 1.98388 |
| `eigenvalues_H_ZF4` | 1 | 1 | `OptimalChi1` | 4.8487 |
| `eigenvalues_H_ZF4` | 1 | 1 | `newChi1` (f11 pattern) | 4.7257 |
| `eigenvalues_H_ZF5` | 7 | t=347 values | literal coverage | 1.98388 |
| `eigenvalues_H_ZF5` | 7 | t=347 values | `OptimalChi1` | 4.7128 |
| `eigenvalues_H_ZF5_v2` | 1 | 1 | literal coverage | 4.42307 |
| `eigenvalues_H_ZF5_v2` | 1 | 1 | `OptimalChi1` | 2.9248 |
| `eigenvalues_H_ZF5_v2` | 1 | 1 | `newChi1` | 2.9359 |
| `orig_eigenvalues_H_ZF_JG` | 1 | 1 | 0 (no vaccination) | 4.42307 |
| `eigenvalues_H_ZF_JG` | 1 | 1 | large random values | 0.93352 |
| `new_eigenvalues_H_ZF_JG` | 1 | 1 | large random values | 0.93352 |

The `x = 7` and `x = 1` rows are not comparable: `x` scales `k`, `ξ`, the
`γ` vectors and `ω` together, so it changes the units of the generation
interval built into `Q`.

---

## 6. Notes on the state of the files

- `eigenvalues_H_ZF2.nb` and `eigenvalues_H_ZF3.nb` are duplicates.
- `eigenvalues_H_ZF2.nb`, `F_ZF_30Dec.nb` and `F_ZF+eig.nb` are mode `600`;
  the rest are group-readable.
- Every notebook re-declares the full data set as literals rather than
  importing the CSVs in `nb_Data`, so the arrays drift between files — `vβ`
  differs by a factor of 25 in `eigenvalues_H.nb`, and `mχ1` takes four
  distinct values across the family.
- Several `Input` cells contain pasted numeric results rather than code
  (`YY`, `ZZ`, `l0`, `newChi1`, `OptimalChi1`, `Sstar`), which is how values
  move between notebooks.
- The ODE model that produced `soln1` is not among these files.
