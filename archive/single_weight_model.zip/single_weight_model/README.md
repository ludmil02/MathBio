# Archive: the single weight model (archived 2026-11-11)

This archive holds the notes `notes/min_spectral_radius_vaccination.tex` (with its
figures and `suplemental/`) and the Python scripts and results that go with them.
It was replaced by `notes/stratified_seir_ngm.tex` and the updated `code/python/zf_jg.py`
in the repository.

## Why it was replaced

In the old model the next generation matrix is NGM = diag(d) A_c with

    A_c = P A_1 P^T,   A_1 = (1/4) P^T A_c P,   g = y + z,

i.e. A_c has doubled rows *and* doubled columns. Its columns carry one weight per
age group,

    q0 = eta_a p/gamma_a + eta_ps (1-p)/xi + eta_s (1-p)/(gamma_s+delta_s),

taken from the notebook `eigenvalues_H_ZF_JG.nb` (the same q0 is in cell 67 of
John's `Age & Location Stratified SEIR 7 ..._orig.nb`).

The model of Feng, Day, Glasser (J. Theor. Biol. 633 (2026) 112531), Appendix A,
has two weights: q_s for the columns of the naive infected (E_s) and q_m for those
of the partially immune infected (E_p),

    q_s = q0 + eta_h (1-p) delta_s / ((gamma_s+delta_s) gamma_h),
    q_m = eta_a q/gamma_a + eta_pm (1-q)/xi + eta_m (1-q)/(gamma_m+delta_m)
          + eta_h (1-q) delta_m / ((gamma_m+delta_m) gamma_h).

q0 omits the hospital term of q_s and is used in place of q_m. With two weights
the columns of A_c are no longer doubled; the reduction still holds, but with

    A_1 = diag(d_c) C diag(psi_I q_s),   g = y + r z,   r = q_m / q_s,

and in the one dose problem e_p = 1 - r_p (1 - eps1) instead of eps1.

## Size of the difference

rho(NGM) with the two weights equals rho(F V^-1) of the full 8-state system to
12 digits; with q0 it does not:

| data, chi                          | two weights (= F V^-1) | single weight q0 |
|------------------------------------|------------------------|------------------|
| 4 x 4, chi = 0                     | 4.440677536267         | 4.423068109191   |
| 4 x 4, chi of F_and_V_ZF_18Jan.nb  | 1.570568657459         | 1.695384975896   |
| 51 x 16, chi = 0 (t = 347)         | 1.307390501274         | 1.303036594051   |

So all optimization results in this archive minimize the spectral radius of a
matrix different from the NGM of the paper.

## Running the scripts

`code/python/zf_jg.py` here is the committed single weight version (the current
one in the repository defaults to two weights; `weights="notebook"` gives q0).
`zf_jg_params.py`, `zf_jg_doses.py` and `notes/bib_mb.bib` are copies. Some scripts
locate the repository as three directories above themselves and read
`old_files/solution_nb_Data/`; unzip at the repository root and adjust that path
(or link `old_files/`) before running them.
