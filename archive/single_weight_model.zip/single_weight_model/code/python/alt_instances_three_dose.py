"""Joint projected Yogi for K iterations, then the alternating method of
Section 4.1, then joint projected Yogi to tol = 1e-10, on the 36 instances of
test_barycenter_three_dose.py, from the 49 starts of gs_three_dose.py.

A start is successful if its rho <= rho_ref (1 + 1e-7), rho_ref the smallest rho
of the 69 interior point runs per instance (test_barycenter_three_dose_results.txt).
A start that is not successful with K = 200 is run again with K = 400, then 800.

Caps: SWEEPS sweeps of the alternating method, YOGI2_TMAX iterations of the
chi_2 step per sweep, POLISH_TMAX iterations of the final joint Yogi.  A run
that reaches a cap is recorded as it ends (and counts as failed if its rho is
above the reference).

Instances are run from the easiest to the hardest, ordered by the iterations of
joint projected Yogi from the barycenter (yogi_instances_three_dose_results.txt),
in parallel, one process per instance.  One line per start is printed; the
per-start results of an instance are appended to OUT when the instance ends.

Usage:
    python3 -u alt_instances_three_dose.py [--procs P]
"""

import argparse
import time
from multiprocessing import Pool
import numpy as np

import gs_three_dose as T
import alt_three_dose as A
import yogi_three_dose as Y
from test_barycenter_three_dose import set_instance, sigma_pair
from yogi_instances_three_dose import references

OUT = "alt_instances_three_dose_results.txt"
YOGI_RES = "yogi_instances_three_dose_results.txt"
OK = 1e-7
KS = (200, 400, 800)
SWEEPS, YOGI2_TMAX, POLISH_TMAX = 50, 5000, 20000


def label(inst):
    budget, r2, r3, sig = inst[:4]
    return "%s b2/b1=%.4g b3/b1=%.4g %s" % (budget, r2, r3, sig)


def difficulty():
    out = {}
    for line in open(YOGI_RES):
        if line.startswith("#"):
            continue
        f = line.split()
        out[(f[0], float(f[1]), float(f[2]), f[3].replace("_", " "))] = int(f[7])
    return out


def run_instance(inst):
    budget, r2, r3, sig, ref = inst
    days = 1.0 if budget == "weekly" else 7.0
    set_instance(days, r2, r3, sig)
    s2, s3 = sigma_pair(sig)
    b = T.b1 / days
    A.SIG = [T.S_.ravel(), s2.ravel(), s3.ravel()]
    A.B = [b, r2 * b, r3 * b]
    rows = []
    for name, x0 in T.starts():
        tries, kok = [], 0
        for K in KS:
            t0 = time.time()
            try:
                x, _, _ = Y.yogi(x0, 1e-2, 0.9, 0.999, 1e-8, 1e-10, K)
                x, sw, _, _, _, _ = A.alternate(x, SWEEPS, yogi_tmax=YOGI2_TMAX)
                x, itp, r = Y.yogi(x, 1e-2, 0.9, 0.999, 1e-8, 1e-10, POLISH_TMAX)
                rho = np.exp(T.value_grad(x)[0])
            except AssertionError:
                rho, sw, itp, r = np.nan, -1, -1, np.nan
            tries.append((K, rho, sw, itp, r, time.time() - t0))
            if rho <= ref * (1 + OK):
                kok = K
                break
        rows.append((name, kok, tries))
        last = tries[-1]
        print("  %-40s %-12s K_ok=%3d rho=%.10f (%+.1e) sweeps=%2d polish=%5d r=%.0e %5.1fs"
              % (label(inst), name, kok, last[1], (last[1] - ref) / ref, last[2], last[3], last[4],
                 sum(t[5] for t in tries)), flush=True)
    return inst, rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=12)
    a = ap.parse_args()
    dif = difficulty()
    insts = sorted(references(), key=lambda r: dif[tuple(r[:4])])
    t0 = time.time()
    open(OUT, "w").write("# budget r2 r3 sigma ref start K_ok then per K tried: "
                         "K rho sweeps polish_it r seconds\n")
    allk = []
    with Pool(a.procs) as pool:
        for inst, rows in pool.imap_unordered(run_instance, insts):
            budget, r2, r3, sig, ref = inst
            kk = np.array([r[1] for r in rows])
            allk += list(kk)
            best = np.nanmin([t[1] for r in rows for t in r[2]])
            secs = sum(t[5] for r in rows for t in r[2])
            print("DONE %-40s ref %.10f best %.10f (%+.1e) | ok at K=200: %2d, 400: %2d, 800: %2d, "
                  "never: %2d | %5.0fs [%.0fs elapsed]"
                  % (label(inst), ref, best, (best - ref) / ref, (kk == 200).sum(), (kk == 400).sum(),
                     (kk == 800).sum(), (kk == 0).sum(), secs, time.time() - t0), flush=True)
            with open(OUT, "a") as fh:
                for name, kok, tries in rows:
                    fh.write("%s %.6g %.6g %s %.12f %s %d %s\n"
                             % (budget, r2, r3, sig.replace(" ", "_"), ref, name.replace(" ", "_"), kok,
                                " ".join("%d %.12f %d %d %.3e %.2f" % t for t in tries)))
    kk = np.array(allk)
    print("ALL %d starts: ok at K=200 %d, 400 %d, 800 %d, never %d; %.0f s"
          % (len(kk), (kk == 200).sum(), (kk == 400).sum(), (kk == 800).sum(), (kk == 0).sum(),
             time.time() - t0))
    print("written", OUT)
