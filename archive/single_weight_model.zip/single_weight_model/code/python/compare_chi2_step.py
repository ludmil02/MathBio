"""The alternating method with the chi_2 step by projected Yogi or by the trust
region interior point method, on the starts of tr_alt_instances_three_dose.py
at which the trust region method reached TR_MAXIT iterations.

For each such start: TR_MAXIT trust region iterations, then the alternating
method (r test, r < 1e-10) with each chi_2 step.  Reported: rho, its excess
over rho_ref, the stationarity measure r, sweeps, and the time of the
alternating method alone.

Writes compare_chi2_step_results.txt.

Usage:
    python3 -u compare_chi2_step.py [--procs P]
"""

import argparse
import time
from multiprocessing import Pool
import numpy as np
from scipy.optimize import minimize

import gs_three_dose as T
import alt_three_dose as A
import yogi_three_dose as Y
from test_barycenter_three_dose import set_instance, sigma_pair
from yogi_instances_three_dose import references

RES = "tr_alt_instances_three_dose_results.txt"
OUT = "compare_chi2_step_results.txt"
TR_MAXIT, SWEEPS, R_TOL = 500, 1000, 1e-10


def cases():
    out = {}
    for line in open(RES):
        if line.startswith("#"):
            continue
        f = line.split()
        if int(f[8]) != 0:
            key = (f[0], float(f[1]), float(f[2]), f[3].replace("_", " "), float(f[4]))
            out.setdefault(key, []).append(f[5].replace("_", " "))
    return out


def run(item):
    (budget, r2, r3, sig, ref), names = item
    days = 1.0 if budget == "weekly" else 7.0
    set_instance(days, r2, r3, sig)
    s2, s3 = sigma_pair(sig)
    b = T.b1 / days
    A.SIG = [T.S_.ravel(), s2.ravel(), s3.ravel()]
    A.B = [b, r2 * b, r3 * b]
    opts = dict(T.OPTS)
    opts["maxiter"] = TR_MAXIT
    st = dict(T.starts())
    rows = []
    for name in names:
        res = minimize(T.value_grad, st[name], jac=True, method="trust-constr",
                       constraints=[T.simplices(3)], bounds=[(0.0, None)] * (3 * T.N), options=opts)
        x0 = T.project(res.x)
        out = []
        for meth in ("yogi", "tr"):
            A.CHI2_METHOD = meth
            t0 = time.time()
            x, sw, _, _, _, it2 = A.alternate(x0, SWEEPS, yogi_tol=1e-11, yogi_tmax=20000, r_tol=R_TOL)
            el = time.time() - t0
            f, gr = T.value_grad(x)
            rho = np.exp(f)
            out.append((rho, (rho - ref) / ref, Y.stationarity(x, gr), sw, it2, el))
        rows.append((name, out))
        (ry, ey, sy, wy, iy, ty), (rt, et, st_, wt, it_, tt) = out
        print("  %s %.4g %.4g %-15s %-12s | yogi: %+.1e r=%.0e sweeps=%2d inner=%5d %5.2fs"
              " | tr: %+.1e r=%.0e sweeps=%2d inner=%5d %5.2fs"
              % (budget, r2, r3, sig, name, ey, sy, wy, iy, ty, et, st_, wt, it_, tt), flush=True)
    return (budget, r2, r3, sig, ref), rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=12)
    a = ap.parse_args()
    items = list(cases().items())
    print("%d instances, %d starts" % (len(items), sum(len(v) for _, v in items)), flush=True)
    t0 = time.time()
    allrows = []
    with Pool(a.procs) as pool:
        for inst, rows in pool.imap_unordered(run, items):
            allrows += [(inst, r) for r in rows]
    with open(OUT, "w") as fh:
        fh.write("# budget r2 r3 sigma start | per method (yogi, tr): rel r sweeps inner_it seconds\n")
        for (b, r2, r3, sig, ref), (name, out) in allrows:
            fh.write("%s %.6g %.6g %s %s %s\n" % (b, r2, r3, sig.replace(" ", "_"), name.replace(" ", "_"),
                     " ".join("%.3e %.3e %d %d %.2f" % o[1:] for o in out)))
    for k, meth in enumerate(("yogi", "tr")):
        rel = np.array([o[k][1] for _, (_, o) in allrows])
        r = np.array([o[k][2] for _, (_, o) in allrows])
        sw = np.array([o[k][3] for _, (_, o) in allrows])
        tm = np.array([o[k][5] for _, (_, o) in allrows])
        print("%-4s: at ref %d/%d, worst %+.1e, r max %.0e, sweeps median %d max %d, "
              "time median %.2fs total %.0fs"
              % (meth, (rel <= 1e-7).sum(), len(rel), rel.max(), r.max(), np.median(sw), sw.max(),
                 np.median(tm), tm.sum()), flush=True)
    print("total %.0f s, written %s" % (time.time() - t0, OUT))
