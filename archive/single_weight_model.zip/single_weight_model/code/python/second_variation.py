"""The first and second variation of Theta of (4.3), Appendix C of the main document.

Theta(u) = Phi(xi(u)), Phi(xi) = log rho(A1 diag(e^xi)), xi = log g(chi(u)).
With M = A1 diag(g), M v = rho v, w^T M = rho w^T, w^T v = 1, phi = w o v:
  grad Phi = phi,
  hess Phi = -diag(phi) + phi phi^T + rho (W R V + V R^T W),
where y = R x solves the bordered system
  (rho I - M) y + alpha v = x - v (w^T x),   w^T y = 0,
here by GMRES, matrix-free; R^T is the same with M^T and v, w exchanged.
log g = log P - log Q with P, Q multilinear in chi (Lemma C.3).

Checks, on the weekly instance of gs_three_dose.py, at the barycenter and at a
random interior point of the simplices:
  the gradient against value_grad of gs_three_dose.py (complex step in g);
  H h against central differences of the gradient, for three tangent h;
  h^T H h against the second difference of Theta.

Usage, from code/python:
    python3 -u second_variation.py
"""

import numpy as np
import scipy.sparse as sps
import scipy.sparse.linalg as spsl

import gp_single_dose as G
import gs_three_dose as T

N, a1, A1 = T.N, T.a1, T.A1
e1, e2, e3, om, omv = T.e1, T.e2, T.e3, T.om, T.omv
S = np.array(T.SCALES)                      # chi_k = S[k] * u_k = b_{k,i} / sigma_{k,p} * u_k
c, d = e2 / om, e2 * e3 / om**2
SEED = 1


def logg_derivs(x1, x2, x3):
    """(C.9)-(C.10): gradient (3, N) and Hessian (3, 3, N) of log g in chi."""
    P = omv + (1 - e1) * x1 + e2 * x2 + c * x1 * x2
    Q = omv + x1 + e2 * x2 + 2 * c * x1 * x2 + d * x1 * x2 * x3
    z = np.zeros_like(x1)
    dP = np.array([(1 - e1) + c * x2, e2 + c * x1, z])
    dQ = np.array([1 + 2 * c * x2 + d * x2 * x3, e2 + 2 * c * x1 + d * x1 * x3, d * x1 * x2])
    hP = np.zeros((3, 3, N))
    hQ = np.zeros((3, 3, N))
    hP[0, 1] = hP[1, 0] = c
    hQ[0, 1] = hQ[1, 0] = 2 * c + d * x3
    hQ[0, 2] = hQ[2, 0] = d * x2
    hQ[1, 2] = hQ[2, 1] = d * x1
    gr = dP / P - dQ / Q
    he = (hP / P - dP[:, None] * dP[None] / P**2) - (hQ / Q - dQ[:, None] * dQ[None] / Q**2)
    return gr, he


class Variation:
    """Theta, its gradient and Hessian-vector products at one point u-hat."""

    def __init__(self, x):
        x = np.asarray(x).reshape(3, N)
        chi = S * x
        g = T.gfun(*chi)
        self.rho, v, w = G.rho_reduced(a1, g)
        w = w / (w @ v)
        self.v, self.w, self.phi = v, w, w * v
        self.M = (A1 @ sps.diags(g)).tocsr()
        gr, he = logg_derivs(*chi)
        self.J = S * gr                                    # d xi_p / d u_{k,p}
        self.H3 = S[:, None] * S[None] * he                # d2 xi_p / du_{k,p} du_{l,p}
        self.theta = np.log(self.rho)
        self.grad = (self.J * self.phi).ravel()
        rho = self.rho
        op = lambda z: np.concatenate([rho * z[:N] - self.M @ z[:N] + v * z[N], [w @ z[:N]]])
        opT = lambda z: np.concatenate([rho * z[:N] - self.M.T @ z[:N] + w * z[N], [v @ z[:N]]])
        self.B = spsl.LinearOperator((N + 1, N + 1), matvec=op)
        self.BT = spsl.LinearOperator((N + 1, N + 1), matvec=opT)

    def R(self, x, transpose=False):
        a, b = (self.w, self.v) if transpose else (self.v, self.w)
        rhs = np.concatenate([x - a * (b @ x), [0.0]])
        y, info = spsl.gmres(self.BT if transpose else self.B, rhs, tol=1e-14, atol=0,
                             restart=N + 1)
        assert info == 0
        return y[:N]

    def hess_phi(self, dxi):
        phi, v, w = self.phi, self.v, self.w
        return (-phi * dxi + phi * (phi @ dxi)
                + self.rho * (w * self.R(v * dxi) + v * self.R(w * dxi, True)))

    def hessvec(self, h):
        h = np.asarray(h).reshape(3, N)
        y = self.hess_phi((self.J * h).sum(0))
        return (self.J * y + self.phi * np.einsum("kln,ln->kn", self.H3, h)).ravel()


def tangent(rng):
    h = rng.standard_normal((3 * T.m, T.n))
    h = h - h.mean(1, keepdims=True)
    return (h / np.abs(h).max()).ravel()


if __name__ == "__main__":
    rng = np.random.default_rng(SEED)
    r = rng.uniform(0.2, 1.0, (3 * T.m, T.n))
    pts = {"barycenter": np.full(3 * N, 1.0 / T.n),
           "random interior": (r / r.sum(1, keepdims=True)).ravel()}
    for name, x in pts.items():
        s = Variation(x)
        th, gref = T.value_grad(x)
        print(f"{name}: rho = {s.rho:.12f}")
        print(f"  gradient against value_grad: relative difference "
              f"{np.abs(s.grad - gref).max() / np.abs(gref).max():.1e}")
        for t in range(3):
            h = tangent(rng)
            Hh = s.hessvec(h)
            err = min(np.abs(Hh - (T.value_grad(x + eps * h)[1] - T.value_grad(x - eps * h)[1])
                             / (2 * eps)).max() / np.abs(Hh).max() for eps in (1e-4, 1e-5))
            eps = 1e-3
            q = (T.value_grad(x + eps * h)[0] - 2 * th + T.value_grad(x - eps * h)[0]) / eps**2
            print(f"  h{t}: H h against differences of the gradient {err:.1e};  "
                  f"h^T H h = {h @ Hh:.6e}, second difference of Theta {q:.6e}")
